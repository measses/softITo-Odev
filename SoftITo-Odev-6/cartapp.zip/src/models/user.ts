export interface User{
    id:number;
    fullName:string;
}