export interface ProductImage{
    id:number;
    small:string;
    medium:string;
    large:string;
}